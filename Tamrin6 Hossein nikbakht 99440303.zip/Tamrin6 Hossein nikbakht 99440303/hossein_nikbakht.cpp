#include<iostream>
#include<time.h>
#include<stdlib.h>
#include<Windows.h>
using namespace std;

char game[3][3] = { {'_','_', '_'},{ '_','_', '_' },{ '_','_', '_' } };
void game_board();
int check_winner(int c,int p) {
	int n, n1, n2 = 0, n3 = 0, m = 0, k = 2;
	char ch;
	if (c == 1)
		ch = 'X';
	else
		ch = 'O';
	for (int i = 0; i < 3; i++){
		n = 0;
		n1 = 0;
		for (int j = 0; j < 3; j++){
			if (game[i][j] == ch) 
				n++;
			if (game[j][i] == ch)
				n1++;
			if (i == j && game[i][j] == ch)
				n2++;
			if (game[i][j] == '_')
				m++;
		}
		if (game[i][k--] == ch)
			n3++;
		if (n == 3 || n1 == 3 || n2==3 || n3==3)
		{
			if (p == 2)
				cout << "*player " << c << " Wins*";
			else if(c==2)
				cout << "*Computer Wins*";
			else
				cout<<"*You Wins*";
			return 1;
		}
	}
	if (m == 0) {
		cout << "Tow platers were drawn.";
		return 1;
	}
	return 0;
}

int main(int argc, char** argv)
{
	
	clock_t timee;
	timee = clock();
	int row, column;
	int n,p;
	while (true)
	{
		cout << "Enter 1 for 1 player \nEnter 2 for 2 players \n Enter:";
		cin >> p;
		system("cls");
		if (p == 1 || p == 2)
			break;
		else
			cout << "out of range!!!\n";
	}
	game_board();
	char ch;
	for (int i = 1; true; i++) {
		if (i % 2){
			n = 1;
			ch = 'X';
		}
		else {
			n = 2;
			ch = 'O';
		}
		if (p == 2) {
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), n*5-1);
			cout << "Player " << n << " : \n";
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 7);
		}
		while (true)
		{
			if (n == 1 || p == 2) {
				cout << "Enter the row between(1-3): ";
				cin >> row;
				row--;
				cout << "Enter the column between(1-3): ";
				cin >> column;
				column--;
			}
			else {
				int k[9][2],h=0,l;
				for (int i = 0; i < 3; i++) 
					for (int j = 0; j < 3; j++) 
						if (game[i][j] == '_') {
							k[h][0] = i;
							k[h][1] = j;
							h++;
						}
				srand(time(0));
				l = rand() % h;
				row = k[l][0];
				column = k[l][1];
			}
			if (0 <= row && row <= 2 && 0 <= column && column <= 2)
			{
				if (game[row][column] == '_')
				{
					game[row][column] = ch;
					break;
				}
				else
					cout << "is not empty!!!\n";
			}
			else
				cout << "out of range!!!\n";
		}
		system("cls");
		game_board();
		if (check_winner(n,p))
			break;
	}
	timee = clock() - timee;
	cout << "\n\ntime = " << ((float)timee) / CLOCKS_PER_SEC<<" secend";
    return 0;
}

void game_board() {
	cout << "\n";
	for (int i = 0; i < 3; i++){
		for (int j = 0; j < 3; j++){
			if (game[i][j] == 'X')
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
			else if (game[i][j] == 'O')
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
			cout << "  " << game[i][j];
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 7);
		}
		cout << "\n\n";
	}
}
